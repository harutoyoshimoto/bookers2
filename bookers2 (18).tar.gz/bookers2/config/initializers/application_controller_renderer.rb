# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '3ee70ec371f742cf62e90dd24bd648f17e4884b0dde53208fbbc7dab9eb15b185caec206d06ba23687a15b796900b7490264931ff07972adfb2d5746e3d55a36'