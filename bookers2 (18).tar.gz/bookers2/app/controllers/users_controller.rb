class UsersController < ApplicationController

  def show
    @user = User.find(params[:id])
    @books = @user.books #そのユーザ（@user）に関連付けられた投稿（books）のみ、@booksに渡す
  end

  def edit
    @user = User.find(params[:id])
    if current_user.id == @user.id
      render :edit
    else
      redirect_to user_path(current_user.id)
    end
  end

  def index
    @user = current_user
    @users = User.all
  end

  def update
    @user = User.find(params[:id])
    if @user.update(user_params)
      flash[:notice] = "You have updated user successfully."
      redirect_to user_path(@user.id) #Update User後、/user/user.idに
    else
      render :edit
    end

  end

  private

  def user_params
    params.require(:user).permit(:name, :introduction, :profile_image)
  end


end
